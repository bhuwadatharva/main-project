import React from "react";

export default function Hero() {
    return (
        <section>
            <img src="..images/zelda-photo.jpg" className="zelda--img" />
            <h2>An epic adventure across the land and skies of Hyrule awaits</h2>
            <button onclick="btn-available" className="btn--01">Available now</button>
        </section>
    )
}