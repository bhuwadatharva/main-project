export default [
    {
        id: 1,
        title: "Everybody 1-2-switch! Pre-order now ",
        price: 380,
        coverImg: "everybody.jpg",  
        location: "Online",
        openSpots: 0,
    },
    {
        id: 2,
        title: "Pikmin 4 Pre-order Now",
        price: 125,
        coverImg: "pikmin-4.jpg",
        location: "Online",
        openSpots: 27,
    },
    {
        id: 3,
        title: "Available Now",  
        price:00,
        coverImg: "Available.jpg",
        location: "Online",
        openSpots: 3,
    },
    {
        id: 4,
        title: "Advance War 1+2! Reboot",  
        price:800,
        coverImg: "advance war.jpg",
        location: "Online",
        openSpots: 3,
    },
    {
        id: 5,
        title: "Splatton 3 Sizzle Season",  
        price:1.5,
        coverImg: "splatoon-3.jpg",
        location: "Online",
        openSpots: 3,
    },
    {
        id: 6,
        title: "Register by June 20222 for chance to attend",
        price:400,
        coverImg:"ninetendo live.jpg",
        location: "online",
        openSpots:00,
    },
    { id: 7,
        title: "Fortnite x Spider World",  
        price:1.5,
        coverImg: "fortnite.jpg",
        location: "Online",
        openSpots: 3,
    },
       
    


]